import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {
  PendientesFacturacionDTO,
  CrearFacturaV2Request,
  FacturaV2Response
} from '../interfaces/facturacion-v2';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class FacturacionV2Service {
  private baseUrl = 'http://localhost:9018/api/facturacion-v2';

  constructor(private http: HttpClient) {}

  // ✅ Pendientes de facturar por cliente
  getPendientes(clienteId: number): Observable<PendientesFacturacionDTO> {
    return this.http.get<PendientesFacturacionDTO>(`${this.baseUrl}/pendientes/cliente/${clienteId}`);
  }

  // ✅ Crear factura (borrador)
  crearFactura(req: CrearFacturaV2Request): Observable<FacturaV2Response> {
    return this.http.post<FacturaV2Response>(`${this.baseUrl}/facturas`, req);
  }

  // ✅ Cancelar borrador
  cancelarBorrador(facturaId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/facturas/${facturaId}`);
  }

  // ✅ Emitir
  emitirFactura(facturaId: number): Observable<FacturaV2Response> {
    return this.http.post<FacturaV2Response>(`${this.baseUrl}/facturas/${facturaId}/emitir`, {});
  }

  // ✅ Listar facturas (por cliente / estado)
  listarFacturas(estado?: string, clienteId?: number): Observable<FacturaV2Response[]> {
    const params: any = {};
    if (estado) params.estado = estado;
    if (clienteId != null) params.clienteId = clienteId;

    return this.http.get<FacturaV2Response[]>(`${this.baseUrl}/facturas`, { params });
  }

  // ✅ Detalle de una factura por ID (MISMO prefijo baseUrl)
  getFacturaById(id: number): Observable<FacturaV2Response> {
    return this.http.get<FacturaV2Response>(`${this.baseUrl}/facturas/${id}`);
  }
}
