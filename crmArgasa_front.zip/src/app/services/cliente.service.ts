import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ICliente } from '../interfaces/icliente';
import { ITrabajo } from '../interfaces/itrabajo';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ClientesService {
  private readonly apiUrl = `${environment.apiUrl}/clientes`;

  private readonly jsonHeaders = new HttpHeaders({
    'Content-Type': 'application/json',
    Accept: 'application/json',
  });

  constructor(private http: HttpClient) {}

  getClientes(): Observable<ICliente[]> {
    return this.http.get<ICliente[]>(this.apiUrl);
  }

  getCliente(id: number): Observable<ICliente> {
    return this.http.get<ICliente>(`${this.apiUrl}/${id}`);
  }

  crearCliente(cliente: ICliente): Observable<ICliente> {
    return this.http.post<ICliente>(this.apiUrl, this.limpiarPayload(cliente), {
      headers: this.jsonHeaders,
      responseType: 'json',
    });
  }

  actualizarCliente(id: number, cliente: ICliente): Observable<ICliente> {
    return this.http.put<ICliente>(
      `${this.apiUrl}/${id}`,
      this.limpiarPayload(cliente),
      {
        headers: this.jsonHeaders,
        responseType: 'json',
      },
    );
  }

  eliminarCliente(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  buscarClientes(texto: string): Observable<ICliente[]> {
    const params = new HttpParams().set('texto', (texto ?? '').trim());
    return this.http.get<ICliente[]>(`${this.apiUrl}/buscar`, { params });
  }

  agregarTrabajo(idCliente: number, trabajo: ITrabajo): Observable<ICliente> {
    return this.http.post<ICliente>(
      `${this.apiUrl}/${idCliente}/trabajos`,
      trabajo,
      {
        headers: this.jsonHeaders,
        responseType: 'json',
      },
    );
  }

  private limpiarPayload(cliente: ICliente): Partial<ICliente> {
    const { empresa, saldoDebe, saldoPagado, pendiente, ...resto } = cliente;
    return resto;
  }

  getProductosCliente(
    clienteId: number,
    empresa: string,
    excludeRutaId?: number | null,
  ) {
    let url = `${this.apiUrl}/${clienteId}/productos/pendientes`;

    if (excludeRutaId != null) {
      url += `?excludeRutaId=${excludeRutaId}`;
    }

    return this.http.get<any[]>(url, {
      headers: { 'X-Empresa': empresa },
    });
  }
}
